package proje.sj;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class UserAccountSys {
    private static ArrayList<UserAccount> list = new ArrayList<>();
    
    public static boolean checkId(String id){
        for(int i = 0;i<list.size();i++){
            if(list.get(i).getAccountId().equalsIgnoreCase(id))
                return true;
        }
        return false;
    }
    public static UserAccount searchId(String id){
        
        for(int i = 0; i<list.size();i++){
            if(checkId(list.get(i).accountId))
                return list.get(i);
        }
        return null;
    }
    public static void addAccount(String accountId, String password, 
                                   String name, String surname, double funds, 
                                   double percentage, double salary, 
                                   String country, Set<Currencies> currencyList,
                                   int duration, int intendedAmount,  String choice,String currChoice,double interest){
       
        
        Scanner input = new Scanner(System.in);
        
        SavingAccount sa;
        ForeignAccount fa;
        if(!checkId(accountId)){
            if(choice.equalsIgnoreCase("savingaccount")){
                sa = new SavingAccount(accountId, password, name, surname, funds, salary, percentage ,duration, intendedAmount,interest);
                sa.setInterest(sa.calculateInterest());
                
                list.add(sa);
                
                
            }
            else if(choice.equalsIgnoreCase("foreignaccount")){
                fa= new ForeignAccount(accountId, password, name, surname, funds, salary, percentage,country, (HashSet<Currencies>) currencyList,currChoice,interest);
                fa.setSalary(fa.convert(currChoice));
                fa.setInterest(fa.calculateInterest());

                list.add(fa);
                
            }
        }
      
    }
    public static boolean removeAccount(String id){
        for(int i=0;i<list.size();i++){
            if(list.get(i).getAccountId().equalsIgnoreCase(id)){
                list.remove(i);
                return true;
            }    
        }
        return false;
    }
    public static String displayAcc(String ID){
        UserAccount temp = searchId(ID); 
        if(temp==null)
            return "\nThe User with id :" + ID + "does not exist";
        else{
        return temp.toString();
            
        }
        
    }  
    public static double deposit(String id, double amount){
      for(int i=0;i<list.size();i++){
          if(list.get(i).getAccountId().equalsIgnoreCase(id)){
              list.get(i).setFunds(amount);
              return list.get(i).getFunds();
          }
      }
      return -1;
    } 
    public static double withdraw(String id, double amount){
        for(int i = 0;i<list.size();i++){
            if(list.get(i).getAccountId().equalsIgnoreCase(id)){
                list.get(i).setFunds(-amount);
                return list.get(i).getFunds();
            }
        }
        return -1;
        
    } 
    public static boolean transferFunds(UserAccount acc, String id2, double amount){

         acc.funds-=amount;
         searchId(id2).funds+=amount;
         
         if(!checkId(id2))
             return false;
         return true; 
    }

    public static ArrayList<UserAccount> getList() {
        return list;
    }


    
    
}
