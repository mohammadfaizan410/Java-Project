package proje.sj;

public abstract class UserAccount {
    protected String accountId;
    protected String password;
    protected String name;
    protected String surname;
    protected double interest;
    protected double funds;
    protected double salary;
    protected double percentage;
    

    public UserAccount(String accountId, String password, String name, String surname, double funds, double salary, double percentage, double interest) {
        this.accountId = accountId;
        this.password = password;
        this.name = name;
        this.surname = surname;
        this.funds = funds;
        this.salary = salary;
        this.percentage = percentage;
        this.interest=interest;
    }


    public String getAccountId() {
        return accountId;
    }
    public String getPassword() {
        return password;
    }
    public String getName() {
        return name;
    }
    public String getSurname() {
        return surname;
    }
    public double getFunds() {
        return funds;
    }
   
    public double getSalary() {
        return salary;
    }
    public double getPercentage() {
        return percentage;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }
    public void setPercentage(double percentage) {
        this.percentage = percentage;
    } 
    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }
    public void setPassword(String password) {
        this.password = password;
    }
    public void setName(String name) {
        this.name = name;
    }
    public void setSurname(String surname) {
        this.surname = surname;
    }
    public void setFunds(double funds) {
        this.funds += funds;
    }

    public void setInterest(double interest) {
        this.interest = interest;
    }
   
    
 
    public boolean findId(String id){
        if(accountId.equalsIgnoreCase(id)){
            return true;
    }
        else 
            return false;
    }
    
    public abstract double calculateInterest();
    
   public String toString(){
       return " \nAccount ID: "+accountId+
               "\nPassword:"+password+
               "\nName: "+name+
               "\nSurname: ";
   }
    
    
}
