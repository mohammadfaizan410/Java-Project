
package proje.sj;

public class PROJESJ {
public static void main(String[] args) {
     BankingFrame bFrame = new BankingFrame();
     bFrame.setVisible(true);
    }
    
}
