
package proje.sj;

public interface BankingInterface {
    public abstract double calculateTotal();
}
