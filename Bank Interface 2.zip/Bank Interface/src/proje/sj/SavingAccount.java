 
package proje.sj;

public class SavingAccount extends UserAccount implements BankingInterface {
    private int duration;
    private int intendedAmount;

    public SavingAccount(String accountId, String password, String name, String surname, double funds, double salary, double percentage,int duration, int intendedAmount, double interest) {
        super(accountId, password, name, surname, funds,  salary, percentage,interest);
        this.duration = duration;
        this.intendedAmount = intendedAmount;
    }
   
    @Override
    public double calculateInterest() {
        if(duration>1&&duration<3){
            percentage=0.07;
        }
        else if(duration>3&&duration<6){
            percentage=0.115;
        }
        else if(duration>6&&duration<12){
            percentage=0.31;
        }
        else if(duration>12&&duration<24){
            percentage=2;
        }
        else if(duration>24&&duration<60){
            percentage=4.7;
        }
        else if(duration>60&&duration<120){
            percentage=12;
    }
        return salary*percentage;
    }
    
   
    public String toString(){
        return " \nSaving Account : " + super.toString()
                + "\nDuration: "+duration+
                "\nIntended Amount: "+intendedAmount + "\nFunds : " + Math.round(super.funds) + "TL" + "\nInterest :" + Math.round(super.interest) + "TL" ;
    }

    @Override
    public double calculateTotal() {
        return funds;
    }
    
}
