package proje.sj;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class ForeignAccount extends UserAccount{
    private String country;
    private String currChoice;
    private Set<Currencies> currencyList = new HashSet<Currencies>();
 

    public ForeignAccount(String accountId, String password, String name, String surname, double funds, double salary, double percentage ,String country,HashSet<Currencies> currencyList,String currChoice, double interest) {
        super(accountId, password, name, surname, funds, salary, percentage,interest);
        this.currencyList= currencyList;
        this.country = country;
        this.currChoice=currChoice;
    }
    
   
 
    
    public double convert(String currChoice){
       for(int i = 0 ; i<currencyList.size();i++){
           if(currChoice.equalsIgnoreCase("dollar")){
               
               return salary/14.4;
             
           }
           else if(currChoice.equalsIgnoreCase("euro")){
              return salary/15.58;
           }
           else if(currChoice.equalsIgnoreCase("pound")){
              return salary/ 18.25;
           }
          
          
       }
       
         return -1;       
    }

    @Override
    public double calculateInterest() {
        
        
        if(salary<100){
            percentage=0.07;
        }
        else if(salary<200){
            percentage=0.115;
        }
        else if(salary<500){
            percentage=0.31;
        }
        else 
            percentage=2;
        return salary*percentage;
    }
        
    

    public void setCurrencyList(HashSet<Currencies> currencyList) {
        this.currencyList = currencyList;
    }
    
    public String displayCurrency(){
        String res=""; 
        Iterator<Currencies> it = currencyList.iterator();
        while(it.hasNext()){
            res += it.next();
        }
        return res;
    }
    
    
    

    @Override
    public String toString() {
        String res = displayCurrency();
        return "\nForeignAccount : \n country :" + country + "\nChosen Currency :" + currChoice + " \ncurrencyList : " + res  + super.toString() + "\nFunds : " + Math.round(super.funds) + " " + currChoice + "\nInterest :" + Math.round(super.interest) + " " + currChoice;
    }
    
}



